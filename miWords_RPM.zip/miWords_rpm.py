import os, sys, pickle, numpy as np, RNA
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
from tensorflow.keras.utils import pad_sequences
from keras.models import Sequential, load_model, Model
from Bio.Seq import Seq

model_scalar = pickle.load(open('scaler.pkl', 'rb'))
model = load_model("rpm.h5")

filename=str(sys.argv[1])
infile=[x.strip() for x in open(filename).readlines()]
fastadict={}; copy_dict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line


ids = list(fastadict.keys())
seq = list(fastadict.values())
for j, i in enumerate(ids):
	fastadict[i] = len(seq[j])
	copy_dict[i] = seq[j]

filename2=str(sys.argv[2])
f1 = open(filename2,'r' )
l1=[]
l2=[]
l3=[]
l6=[]
for each in f1:
	z=each.split()
	l1.append(str(z[0]))
	l6.append(str(z[5]))
	l2.append(int(z[1]))
	l3.append(int(z[2]))

f1.close()

filename3=str(sys.argv[3])
f1 = open(filename3,'r' )
a1=[]
a2=[]
a3=[]
a6=[]
for each in f1:
	z=each.split()
	a1.append(str(z[0]))
	a6.append(str(z[5]))
	a2.append(int(z[1]))
	a3.append(int(z[2]))

f1.close()
mapped_reads = float(len(a1)/1000000)
f3=open(filename+"_rpm.txt",'w')
for m, n in enumerate(l1):
	b={}
	y=[];X=[]
	for i in range(0,fastadict[">"+n]):
		b[i]=0
	for j,x in enumerate(a1):
		if n==x and l6[m]==a6[j]:
			for i in range(int(a2[j]),int(a3[j])+1):
				b[i]+=1
	for i in b:
		y.append(float(b[i]/mapped_reads))
	X.append(y[l2[m]:l3[m]])
	X = model_scalar.transform(np.array(X))
	X = np.array(X).reshape(len(X),280, 1)
	mm= model.predict(X, verbose=0)
	if mm>=0.5 and l6[m]=="-":
		seqs = Seq(copy_dict[">"+n])
		j = seqs.reverse_complement()
		sq=str(j[l2[m]:l3[m]])
		sc=y[l2[m]:l3[m]]
		rna=RNA.fold(sq)[0]
		f3.writelines(n+"\t"+str(l2[m])+"\t"+str(l3[m])+"\t"+l6[m]+"\t"+sq+"\t"+rna+"\n")
		f6=open(n+"_"+str(l2[m])+"-rev.txt",'w')
		f6.writelines("Base\tStructure\tRPM\tLine\n")
		for e,f in enumerate(sc):
			f6.writelines(str(sq[e])+"\t"+str(rna[e])+"\t"+str(f)+"\t"+str(e+1)+"\n")
		f6.close()
	elif mm>=0.5 and l6[m]=="+":
		sq=str(copy_dict[">"+n][l2[m]:l3[m]])
		rna=RNA.fold(sq)[0]
		f3.writelines(n+"\t"+str(l2[m])+"\t"+str(l3[m])+"\t"+l6[m]+"\t"+sq+"\t"+rna+"\n")
		f6=open(n+"_"+str(l2[m])+".txt",'w')
		f6.writelines("Base\tStructure\tRPM\tLine\n")
		for e,f in enumerate(sc):
			f6.writelines(str(sq[e])+"\t"+str(rna[e])+"\t"+str(f)+"\t"+str(e+1)+"\n")
		f6.close()
f3.close()
os.system("mkdir results; mv *.txt results/")

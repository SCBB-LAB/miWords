import os, sys, numpy as np, re, math, os, sys, numpy, pickle, RNA
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import tensorflow as tf, tensorflow, tensorflow.keras as keras
from tensorflow.keras.utils import pad_sequences
from tensorflow.keras.models import load_model

score_model=load_model("score.h5")
def mono_hot_encode(seq):
	mapping = dict(zip([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0], range(10)))  
	seq1 = [mapping[i] for i in seq]
	return np.eye(10)[seq1]


def foo(vals):
	main=[]
	for v in vals:
		if v <= 0.1:
			main.append(float(0.1))
		elif v > 0.1 and v <= 0.2:
			main.append(float(0.2))
		elif v > 0.2 and v <= 0.3:
			main.append(float(0.3))
		elif v > 0.3 and v <= 0.4:
			main.append(float(0.4))
		elif v > 0.4 and v < 0.5:
			main.append(float(0.5))
		elif v >= 0.5 and v <= 0.6:
			main.append(float(0.6))
		elif v > 0.6 and v <= 0.7:
			main.append(float(0.7))
		elif v > 0.7 and v <= 0.8:
			main.append(float(0.8))
		elif v > 0.8 and v <= 0.9:
			main.append(float(0.9))
		elif v > 0.9 and v <= 1.0:
			main.append(float(1.0))
	return main


infile=[x.strip() for x in open(sys.argv[1]+".fa").readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line


path = str(sys.argv[2])+"/plot"
isExist = os.path.exists(path)
if not isExist:
	os.makedirs(path)

li = str(sys.argv[1])+"_header.txt"
f3=[x.strip() for x in open(li).readlines()]
seq=[]
for j in f3:
	se=[]
	f1=open(str(j)+".csv",'r')
	for i in f1:
		z=i.split(",")
		se.append(float(z[1]))
	f1.close()
	alpha=foo(se)
	sequence=[alpha[i:i+280] for i in range(len(alpha)-279)]
	X=[]
	y=[]
	for l,i in enumerate(sequence):
		if i[0]>=0.5:
			X.append(mono_hot_encode(i))
			y.append(int(l))
	X = pad_sequences(X, maxlen=280,padding='post')
	X_cnn = np.array(X).reshape(len(X),280, 10, 1)
	report = score_model.predict(X_cnn, verbose=0)
	f7=open(str(sys.argv[2])+"/plot/"+str(j)+".bed",'w')
	for m, n in enumerate(report):
		if n >=0.5:
			o=y[m]
			k=fastadict[">"+str(j)]
			sq=k[o:o+280]
			mm=RNA.fold(k)[0]	
			sc=sequence[o]
			f7.writelines(str(j)+"\t"+str(o)+"\t"+str(o+1)+"\tabcd\t255\t+\n")
			f6=open(str(sys.argv[2])+"/plot/"+str(j)+"_"+str(o)+".csv",'w')
			f6.writelines("Base\tTriplet\tScore\tLine\n")
			for a, b in enumerate(sq):
				f6.writelines(str(sq[a])+"\t"+str(mm[a])+"\t"+str(sc[a])+"\t"+str(a+1)+"\n")
			f6.close()
	f7.close()
	f1=open(str(j)+"-rev.csv",'r')
	se=[]
	for i in f1:
		z=i.split(",")
		se.append(float(z[1]))
	f1.close()
	alpha=foo(se)
	sequence=[alpha[i:i+280] for i in range(len(alpha)-279)]
	X=[]
	y=[]
	for l,i in enumerate(sequence):
		if i[0]>=0.5:
			X.append(mono_hot_encode(i))
			y.append(int(l))
	X = pad_sequences(X, maxlen=280,padding='post')
	X_cnn = np.array(X).reshape(len(X),280, 10, 1)
	report = score_model.predict(X_cnn, verbose=0)
	f7=open(str(sys.argv[2])+"/plot/"+str(j)+"-rev.bed",'w')
	for m, n in enumerate(report):
		if n >=0.5:
			o=y[m]
			k=fastadict[">"+str(j)]
			sq=k[o:o+280]
			mm=RNA.fold(k)[0]	
			sc=sequence[o]
			f7.writelines(str(j)+"\t"+str(o)+"\t"+str(o+1)+"\tabcd\t255\t-\n")
			f6=open(str(sys.argv[2])+"/plot/"+str(j)+"_"+str(o)+"-rev.csv",'w')
			f6.writelines("Base\tTriplet\tScore\tLine\n")
			for a, b in enumerate(sq):
				f6.writelines(str(sq[a])+"\t"+str(mm[a])+"\t"+str(sc[a])+"\t"+str(a+1)+"\n")
			f6.close()
	f7.close()

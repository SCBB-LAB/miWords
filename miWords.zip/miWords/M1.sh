python3 reve.py $1/$2 >$1/$2\_header.txt
RNAfold --noPS -j $1/$2.fasta|paste - - - |awk '{print $1"\t"$2"\t"$3}' >$1/$2\_rnafold
cat $1/$2\_rnafold |tr '(.)' 'MON' >$1/$2\_feature
python3 miWords.py $1/$2\_feature >$1/$2.log
paste $1/$2_feature.txt $1/$2\_feature |sed 's+\[++'|sed 's+]++' |awk '{if($2>=0.5) {print $3"\tpre-miRNA"} else {print $3"\tNon-pre-miRNA"}}' >$1/sequence_feature.tsv
paste $1/$2_feature.txt $1/$2\_feature |sed 's+\[++' |sed 's+]++' |sed 's+_+\t+2g'|awk '{print $3","$2","$5","$6}'| grep -v rev | tr "MON" "(.)" >$1/seq.txt

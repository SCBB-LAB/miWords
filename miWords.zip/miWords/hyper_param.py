import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
from keras.regularizers import l2, l1
import sys, numpy as np, tensorflow as tf, tensorflow, keras, numpy, pandas as pd, warnings, re, math, xgboost as xgb, numpy, pickle, time, sklearn
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier
from scikeras.wrappers import KerasClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from tensorflow.keras.optimizers import Adam, SGD, RMSprop, Adadelta, Adagrad, Adamax, Nadam, Ftrl
from keras.callbacks import EarlyStopping, ModelCheckpoint
from math import floor
from bayes_opt import BayesianOptimization
from keras.models import Sequential, load_model, Model
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from keras import regularizers, layers
from keras.preprocessing import sequence
from pickle import load
from numpy import array, argmax
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.utils import pad_sequences
from tensorflow.keras.layers import Input, Dense, Flatten, Dropout, Embedding, BatchNormalization, concatenate, LSTM, LeakyReLU
from multiprocessing import Pool
from sklearn.metrics import accuracy_score, recall_score, precision_score, confusion_matrix, classification_report, roc_auc_score, cohen_kappa_score, f1_score, make_scorer
from xgboost_ray import RayDMatrix, RayParams, train, RayXGBClassifier, RayFileType, predict
from ray import tune

class TransformerBlock(layers.Layer):
    def __init__(self, embed_dim, num_heads, ff_dim, rate1, rate2,  rate=0.1):
        super(TransformerBlock, self).__init__()
        self.att = layers.MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim, value_dim=embed_dim)
        self.ffn = keras.Sequential(
            [layers.Dense(ff_dim, activation="relu"), layers.Dense(embed_dim),]
        )
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate1)
        self.dropout2 = layers.Dropout(rate2)
    def call(self, inputs, training):
        attn_output = self.att(inputs, inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)

class TokenAndPositionEmbedding(layers.Layer):
    def __init__(self, maxlen, vocab_size, embed_dim):
        super(TokenAndPositionEmbedding, self).__init__()
        self.token_emb = layers.Embedding(input_dim=vocab_size, output_dim=embed_dim)
        self.pos_emb = layers.Embedding(input_dim=maxlen, output_dim=embed_dim)
    def call(self, x):
        maxlen = tf.shape(x)[-1]
        positions = tf.range(start=0, limit=maxlen, delta=1)
        positions = self.pos_emb(positions)
        x = self.token_emb(x)
        return x + positions


def comparison(testlabel, resultslabel):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for row1 in range(len(resultslabel)):
        if resultslabel[row1] < 0.5:
            resultslabel[row1] = 0
        else:
            resultslabel[row1] = 1
    for row2 in range(len(testlabel)):
        if testlabel[row2] == 1 and testlabel[row2] == resultslabel[row2]:
            TP = TP + 1
        if testlabel[row2] == 0 and testlabel[row2] != resultslabel[row2]:
            FP = FP + 1
        if testlabel[row2] == 0 and testlabel[row2] == resultslabel[row2]:
            TN = TN + 1
        if testlabel[row2] == 1 and testlabel[row2] != resultslabel[row2]:
            FN = FN + 1
    if TP + FN != 0:
        TPR = TP / (TP + FN)
    else:
        TPR = 99999
    if TN + FP != 0:
        TNR = TN / (TN + FP)
    else:
        TNR = 999999
    if TP + FP != 0:
        PPV = TP / (TP + FP)
    else:
        PPV = 999999
    if TN + FN != 0:
        NPV = TN / (TN + FN)
    else:
        NPV = 999999
    if FN + TP != 0:
        FNR = FN / (FN + TP)
    else:
        FNR = 999999
    if FP + TN != 0:
        FPR = FP / (FP + TN)
    else:
        FPR = 999999
    if FP + TP != 0:
        FDR = FP / (FP + TP)
    else:
        FDR = 999999
    if FN + TN != 0:
        FOR = FN / (FN + TN)
    else:
        FOR = 999999
    if TP + TN + FP + FN != 0:
        ACC = (TP + TN) / (TP + TN + FP + FN)
    else:
        ACC = 999999
    if TP + FP + FN != 0:
        F1 = (2 * TP) / (2 * TP + FP + FN)
    else:
        F1 = 999999
    if (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) != 0:
        MCC = (TP * TN + FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    else:
        MCC = 999999
    if TPR != 999999 and TNR != 999999:
        BM = TPR + TNR - 1
    else:
        BM = 999999
    if PPV != 999999 and NPV != 999999:
        MK = PPV + NPV - 1
    else:
        MK = 999999
    return TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK


LeakyReLU = LeakyReLU(alpha=0.1)
warnings.filterwarnings('ignore')
score_acc = make_scorer(accuracy_score)
def create_tokenizer(lines):
	tokenizer = Tokenizer()
	tokenizer.fit_on_texts(lines)
	return tokenizer



def max_length(lines):
	return max([len(s.split()) for s in lines])

def encode_text(tokenizer, lines, length):
	encoded = tokenizer.texts_to_sequences(lines)
	padded = pad_sequences(encoded, maxlen=length, padding='post')
	return padded

def s1(k):
	a=[]
	text3=[testseq1[k][i:i+1] for i in range(len(testseq1[k]))]
	text4=[testseq1[k][i:i+2] for i in range(len(testseq1[k])-(1))]
	text5=[testseq1[k][i:i+5] for i in range(len(testseq1[k])-(4))]
	text6=[test12[k][i:i+3] for i in range(len(test12[k])-(2))]
	texts32=' '.join(text3)
	texts42=' '.join(text4)
	texts52=' '.join(text5)
	texts62=' '.join(text6)
	f1 = int(testlab1[k])
	a.append(str(texts32)+' '+str(texts42)+' '+str(texts52)+' '+str(texts62))
	f2 = encode_text(tokenizer, a, length)
	return f1, f2

with open('tokenizer_penta.pickle', 'rb') as handle:
    tokenizer = pickle.load(handle)

vocab_size = len(tokenizer.word_index) + 1
length = 793
testseq1=[]
testlab1=[];test12=[]
for i in open(sys.argv[1]):
	z=i.split()
	testlab1.append(str(z[0]))
	testseq1.append(str(z[1]))
	test12.append(z[2])


name=[]
name = Pool().map(s1, [sent for sent in range(len(testseq1))])
input_ids=[]
attention_masks=[]
for i, j in enumerate(name):
	input_ids.append(name[i][0])	
	attention_masks.append(name[i][1][0])

train_inp = numpy.array(attention_masks)
train_label = numpy.array(input_ids)
params_nn ={
    'neurons2': (8, 64),
    'neurons': (8, 64),
    'activation':(0, 9),
    'activation3':(0, 9),
    'activation2':(0, 9),
    'optimizer':(0,7),
    'learning_rate':(0.01, 1),
    'batch_size':(20, 140),
    'epochs':(5, 100),
    'embed_dim':(2,128),
    'num_heads':(2,128),
    'ff_dim':(8,64),
    'dropout_rate':(0,0.5),
    'dropout_rate2':(0,0.5),
    'lo':(0,0.5),
    'lt':(0,0.5),
    'lth':(0,0.5),
    'lf':(0,0.5),
    'rate1':(0,0.5),
    'rate2':(0,0.5)
}

def nn_cl_bo(neurons, neurons2, ff_dim, embed_dim, num_heads, activation, activation2, activation3, optimizer, learning_rate, batch_size, epochs, dropout_rate, dropout_rate2, lo, lt, lth, lf, rate1, rate2):
	optimizerL = ['SGD', 'Adam', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','SGD']
	optimizerD= {'Adam':Adam(lr=learning_rate), 'SGD':SGD(lr=learning_rate),
                 'RMSprop':RMSprop(lr=learning_rate), 'Adadelta':Adadelta(lr=learning_rate),
                 'Adagrad':Adagrad(lr=learning_rate), 'Adamax':Adamax(lr=learning_rate),
                 'Nadam':Nadam(lr=learning_rate), 'Ftrl':Ftrl(lr=learning_rate)}
	activationL = ['relu', 'sigmoid', 'sigmoid', 'softplus', 'softsign', 'tanh', 'selu',
                   'elu', 'LeakyReLU','relu']
	neurons = round(neurons)
	neurons2 = round(neurons2)
	activation = activationL[round(activation)]
	activation2 = activationL[round(activation2)]
	activation3 = activationL[round(activation3)]
	optimizer = optimizerD[optimizerL[round(optimizer)]]
	batch_size = round(batch_size)
	ff_dim = round(ff_dim)
	embed_dim = round(embed_dim)
	num_heads = round(num_heads)
	epochs = round(epochs)
	def nn_cl_fun():
		inputs = layers.Input(shape=(793,))
		embedding_layer = TokenAndPositionEmbedding(793, 1248, embed_dim)
		x = embedding_layer(inputs)
		transformer_block = TransformerBlock(embed_dim, num_heads, ff_dim, rate1, rate2)
		x = transformer_block(x)
		x = layers.GlobalAveragePooling1D()(x)
		x = layers.Dropout(dropout_rate)(x)
		x = layers.Dense(neurons, activation=activation, kernel_regularizer=l1(lo), bias_regularizer=l2(lt))(x)
		x = layers.Dense(neurons2, activation=activation2, kernel_regularizer=l1(lth), bias_regularizer=l2(lf))(x)
		x = layers.Dropout(dropout_rate2)(x)
		outputs = layers.Dense(1, activation=activation3)(x)
		nn = keras.Model(inputs=inputs, outputs=outputs)
		nn.compile(loss='binary_crossentropy',optimizer=optimizer,metrics=['accuracy'])
		return nn
	es = EarlyStopping(monitor='accuracy', mode='max', verbose=0, patience=20)
	nn = KerasClassifier(build_fn=nn_cl_fun, epochs=epochs, batch_size=batch_size, verbose=0)
	kfold = StratifiedKFold(n_splits=2, shuffle=True, random_state=123)
	score = cross_val_score(nn, train_inp, train_label, scoring=score_acc, cv=kfold)
	score=np.nan_to_num(score)
	score=score.mean()
	return score


nn_bo = BayesianOptimization(nn_cl_bo, params_nn)
nn_bo.maximize(init_points=1, n_iter=4)
params_nn_ = nn_bo.max['params']
learning_rate = params_nn_['learning_rate']
activationL = ['relu', 'sigmoid', 'sigmoid', 'softplus', 'softsign', 'tanh', 'selu','elu', 'LeakyReLU','relu']
params_nn_['activation'] = activationL[round(params_nn_['activation'])]
params_nn_['activation2'] = activationL[round(params_nn_['activation2'])]
params_nn_['activation3'] = activationL[round(params_nn_['activation3'])]
params_nn_['batch_size'] = round(params_nn_['batch_size'])
params_nn_['epochs'] = round(params_nn_['epochs'])
params_nn_['embed_dim'] = round(params_nn_['embed_dim'])
params_nn_['num_heads'] = round(params_nn_['num_heads'])
params_nn_['ff_dim'] = round(params_nn_['ff_dim'])
params_nn_['neurons'] = round(params_nn_['neurons'])
params_nn_['neurons2'] = round(params_nn_['neurons2'])
optimizerL = ['Adam', 'SGD', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','Adam']
optimizerD= {'Adam':Adam(lr=learning_rate), 'SGD':SGD(lr=learning_rate),
	     'RMSprop':RMSprop(lr=learning_rate), 'Adadelta':Adadelta(lr=learning_rate),
	     'Adagrad':Adagrad(lr=learning_rate), 'Adamax':Adamax(lr=learning_rate),
	     'Nadam':Nadam(lr=learning_rate), 'Ftrl':Ftrl(lr=learning_rate)}
params_nn_['optimizer'] = optimizerD[optimizerL[round(params_nn_['optimizer'])]]
f1=open("param.txt",'w')
for i in params_nn_:
	f1.writelines(str(i)+"\t"+str(params_nn_[i])+"\n")

f1.close()

X_train, X_test, y_train, y_test = train_test_split(train_inp, train_label, test_size=0.30, random_state=42)
embed_dim = int(params_nn_['embed_dim'])
num_heads = int(params_nn_['num_heads'])
ff_dim = int(params_nn_['ff_dim'])
inputs = layers.Input(shape=(length,))
embedding_layer = TokenAndPositionEmbedding(length, vocab_size, embed_dim, float(params_nn_['rate1']), float(params_nn_['rate2']))
x = embedding_layer(inputs)
transformer_block = TransformerBlock(embed_dim, num_heads,ff_dim)
x = transformer_block(x)
x = layers.GlobalAveragePooling1D()(x)
x = layers.Dropout(float(params_nn_['dropout_rate2']))(x)
x = layers.Dense(int(params_nn_['neurons']), activation=params_nn_['activation'])(x)
x = layers.Dense(int(params_nn_['neurons2']), activation=params_nn_['activation2'], name='my_dense')(x)
x = layers.Dropout(float(params_nn_['dropout_rate2']))(x)
outputs = layers.Dense(1, activation=params_nn_['activation3'])(x)
model = keras.Model(inputs=inputs, outputs=outputs)
model.compile(loss='binary_crossentropy',optimizer=params_nn_['optimizer'],metrics=['accuracy'])
checkpoint_filepath = 'testt/check'
model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint( filepath=checkpoint_filepath, save_weights_only=True, monitor='val_accuracy', mode='max', save_best_only=True)
history = model.fit(X_train, y_train, batch_size=int(params_nn_['batch_size']), epochs=1, validation_data=(X_test, y_test), callbacks=[model_checkpoint_callback])
model.save_weights("model.h5")
model.load_weights("model.h5")
layer_name='my_dense'
intermediate_layer_model = Model(inputs=model.input, outputs=model.get_layer(layer_name).output)
intermediate_output = intermediate_layer_model.predict(X_train) 
X_train = pd.DataFrame(data=intermediate_output)
intermediate_output = intermediate_layer_model.predict(X_test) 
X_test = pd.DataFrame(data=intermediate_output)

dt = RayDMatrix(X_train,label=y_train, enable_categorical=True)
dv = RayDMatrix(X_test,label=y_test, enable_categorical=True)
config = {
    "tree_method": "approx",
    "objective": "binary:logistic",
    "eval_metric": ["logloss", "error"],
    "eta": tune.loguniform(1e-4, 1e-1),
    "subsample": tune.uniform(0.5, 1.0),
    "max_depth": tune.randint(1, 9),
    "gamma": tune.uniform(1,9),
    "reg_alpha" : tune.uniform(40,180),
    "reg_lambda" : tune.uniform(0,1),
    "colsample_bytree" : tune.uniform(0.5,1),
    "min_child_weight" : tune.uniform(0, 10)
}
ray_params = RayParams(num_actors=4, cpus_per_actor=1)
def train_model(config):
    evals_result = {}
    bst = train(
        params=config,
        dtrain=dt,
        evals_result=evals_result,
        evals=[(dt, "train")],
        verbose_eval=False,
        ray_params=ray_params)
    bst.save_model("model.xgb")

analysis = tune.run(
    train_model,
    config=config,
    metric="train-error",
    mode="min",
    num_samples=1,
    resources_per_trial=ray_params.get_tune_resources())

par = analysis.best_config
print(par)
dt = xgb.DMatrix(X_train,label=y_train, enable_categorical=True)
dv = xgb.DMatrix(X_test,label=y_test, enable_categorical=True)
model = xgb.train(par, dt, 3000, [(dt, "train"),(dv, "valid")], verbose_eval=200)
filename = "xgb_test.sav"
pickle.dump(model, open(filename, 'wb'))
model = pickle.load(open(filename, 'rb'))
y_pred = model.predict(dv)
TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK = comparison(y_test,y_pred)
print('TP:', TP, 'FP:', FP, 'TN:', TN, 'FN:', FN)
print('TPR:', TPR, 'TNR:', TNR, 'PPV:', PPV, 'NPV:', NPV, 'FNR:', FNR, 'FPR:', FPR, 'FDR:', FDR, 'FOR:', FOR)
print('ACC:', ACC, 'F1:', F1, 'MCC:', MCC, 'BM:', BM, 'MK:', MK)

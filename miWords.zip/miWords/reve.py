#!user/bin/python
import sys, os
from Bio.Seq import Seq


infile=[x.strip() for x in open(sys.argv[1]).readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line

ids=list(fastadict.keys())
seq = list(fastadict.values())

f3=open(sys.argv[1]+".fasta",'w')
f4=open(sys.argv[1]+"-rev",'w')
for k,j in enumerate(seq):
	j=j.upper()
	j=j.replace('U', 'T')
	j=j.replace('N', 'A')
	if len(j) >=400:
		kmer=[j[i:i+200] for i in range(0,len(j)-199)]
		for n, m in enumerate(kmer):
			f3.writelines(str(ids[k])+"_"+str(n)+"\n"+str(m)+"\n")
		seqs = Seq(j)
		j = seqs.reverse_complement()
		kmer=[j[i:i+200] for i in range(0,len(j)-199)]
		for n, m in enumerate(kmer):
			f3.writelines(str(ids[k])+"_"+str(n)+"-rev\n"+str(m)+"\n")
		print(str(ids[k]).replace('>', ''))
		f4.writelines(str(str(ids[k]).replace('>', '')+"-rev")+"\n")
	else:	
		f3.writelines(str(ids[k])+"_0\n"+str(j)+"\n")
		seqs = Seq(j)
		j = seqs.reverse_complement()
		f3.writelines(str(ids[k])+"_0-rev\n"+str(j)+"\n")
		f4.writelines(str(str(ids[k]).replace('>', '')+"-rev")+"\n")
		print(str(ids[k]).replace('>', ''))


f3.close()
f4.close()


import os, sys, numpy as np, re, math, os, sys, numpy, pickle, RNA
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
from Bio.Seq import Seq
import tensorflow as tf, tensorflow, tensorflow.keras as keras
from tensorflow.keras.utils import pad_sequences
from tensorflow.keras.models import load_model

filename=str(sys.argv[1])

infile=[x.strip() for x in open(filename).readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line


f1=open(filename+".bed",'r')
l1=[]
l2=[]
l3=[]
l4=[]
for i in f1:
	z=i.split()
	l1.append(str(z[0]))
	l2.append(int(z[1]))
	l3.append(int(z[2]))
	l4.append(str(z[5]))

f1.close()
path = str(sys.argv[2])+"/merge"
isExist = os.path.exists(path)
if not isExist:
	os.makedirs(path)

f7=open(str(sys.argv[2])+"/merge.txt",'w')
for i, j in enumerate(l1):
	if l4[i] == '+':
		f6=open(str(sys.argv[2])+"/merge/"+str(j)+"_"+str(i)+".csv",'w')
		f6.writelines("Base\tTriplet\tScore\tLine\n")
		a=fastadict[">"+j][l2[i]:l3[i]]
		f1=open(str(j)+".csv",'r')
		se=[]
		for k in f1:
			z=k.split(",")
			se.append(float(z[1]))
		f1.close()
		sc=se[l2[i]:l3[i]]
		f7.writelines(a+RNA.fold(a)[0]+str(sc)+"\n")
		for c, b in enumerate(a):
			f6.writelines(str(a[c])+"\t"+str(RNA.fold(a)[0][c])+"\t"+str(sc[c])+"\t"+str(c+1)+"\n")
		f6.close()
	else:
		f6=open(str(sys.argv[2])+"/merge/"+str(j)+"_"+str(i)+"-rev.csv",'w')
		f6.writelines("Base\tTriplet\tScore\tLine\n")
		a=str(Seq(fastadict[">"+j][l2[i]:l3[i]]).reverse_complement())
		f1=open(str(j)+"-rev.csv",'r')
		se=[]
		for k in f1:
			z=k.split(",")
			se.append(float(z[1]))
		f1.close()
		sc=se[l2[i]:l3[i]]
		f7.writelines(a+RNA.fold(a)[0]+str(sc)+"\n")
		for c, b in enumerate(a):
			f6.writelines(str(a[c])+"\t"+str(RNA.fold(a)[0][c])+"\t"+str(sc[c])+"\t"+str(c+1)+"\n")
		f6.close()
f7.close()



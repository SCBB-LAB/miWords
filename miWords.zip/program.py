import os, sys
#os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import numpy as np, tensorflow as tf, tensorflow, keras, numpy, pandas as pd, math, xgboost as xgb, numpy, pickle, time, sklearn
from tensorflow.keras.optimizers import Adam, SGD, RMSprop, Adadelta, Adagrad, Adamax, Nadam, Ftrl
from math import floor
from keras.models import Sequential, load_model, Model
from keras import regularizers, layers
from tensorflow.keras.layers import Input, Embedding
from keras.preprocessing import sequence
from pickle import load
from numpy import array, argmax
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.utils import pad_sequences
from keras.layers import Input, Dense, Flatten, Dropout, Embedding, BatchNormalization, concatenate, LSTM, LeakyReLU
from multiprocessing import Pool
from utils import TokenAndPositionEmbedding, TransformerBlock, comparison

def create_tokenizer(lines):
	tokenizer = Tokenizer()
	tokenizer.fit_on_texts(lines)
	return tokenizer


def max_length(lines):
	return max([len(s.split()) for s in lines])


def encode_text(tokenizer, lines, length):
	encoded = tokenizer.texts_to_sequences(lines)
	padded = pad_sequences(encoded, maxlen=length, padding='post')
	return padded



def s1(k):
	a=[]
	text3=[testseq1[k][i:i+1] for i in range(len(testseq1[k]))]
	text4=[testseq1[k][i:i+2] for i in range(len(testseq1[k])-(1))]
	text5=[testseq1[k][i:i+5] for i in range(len(testseq1[k])-(4))]
	text6=[test12[k][i:i+3] for i in range(len(test12[k])-(2))]
	texts32=' '.join(text3)
	texts42=' '.join(text4)
	texts52=' '.join(text5)
	texts62=' '.join(text6)
	f1 = str(testlab1[k])
	a.append(str(texts32)+' '+str(texts42)+' '+str(texts52)+' '+str(texts62))
	f2 = encode_text(tokenizer, a, length)
	return f1, f2



with open('tokenizer_penta.pickle', 'rb') as handle:
    tokenizer = pickle.load(handle)

vocab_size = len(tokenizer.word_index) + 1
length = 793
embed_dim = 28
num_heads = 14
ff_dim = 14
inputs = layers.Input(shape=(length,))
embedding_layer = TokenAndPositionEmbedding(length, vocab_size, embed_dim)
x = embedding_layer(inputs)
transformer_block = TransformerBlock(embed_dim, num_heads,ff_dim)
x = transformer_block(x)
x = layers.GlobalAveragePooling1D()(x)
x = layers.Dropout(0.16)(x)
x = layers.Dense(38, activation="relu")(x)
x = layers.Dense(12, activation="selu", name='my_dense')(x)
x = layers.Dropout(0.17)(x)
outputs = layers.Dense(1, activation="LeakyReLU")(x)
model = keras.Model(inputs=inputs, outputs=outputs)
ada=tf.keras.optimizers.Adadelta(learning_rate=0.583)
model.compile(loss='binary_crossentropy',optimizer=ada,metrics=['accuracy'])
model.load_weights('miWords.h5')
layer_name='my_dense'
intermediate_layer_model = Model(inputs=model.input, outputs=model.get_layer(layer_name).output)

attention=[]
testseq1=[]
testlab1=[];test12=[]
for i in open(sys.argv[1]):
	z=i.split()
	testlab1.append(str(z[0]))
	testseq1.append(str(z[1]))
	test12.append(z[2])


name=[]
name = Pool().map(s1, [sent for sent in range(len(testseq1))])
input_ids=[]
attention_masks=[]
for i, j in enumerate(name):
	input_ids.append(name[i][0])	
	attention_masks.append(name[i][1][0])

X_train = numpy.array(attention_masks)
y_train = numpy.zeros(len(input_ids))
filename = "miWords.sav"
model_xgb = pickle.load(open(filename, 'rb'))
d=3412
z=len(X_train)
t_label=np.zeros(d)
from timeit import default_timer as timer
f3=open(sys.argv[1]+".txt",'w')
def func3(i,alpha,b):
	intermediate_output = intermediate_layer_model.predict(i)
	X_train = pd.DataFrame(data=intermediate_output)
	dt = xgb.DMatrix(X_train,label=alpha)
	y_pred = model_xgb.predict(dt)
	for a,j in enumerate(y_pred):
		f3.writelines(str(b)+"_"+str(a)+"\t"+str(j)+"\n")


for b in range(0,z,d):
	func3(X_train[b:b+d], y_train[b:b+d], b)

f3.close()

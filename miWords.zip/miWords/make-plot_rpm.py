import plotly.graph_objects as go
import plotly.express as px
import os, sys
import pandas as pd
import numpy as np
import plotly.graph_objects as go
filename=str(sys.argv[1])
df = pd.read_csv(filename,sep="\t")
l1=list(df["Base"])
l3=list(df["Structure"])
l2=list(df["Line"])
l4=[]
for i, j in enumerate(l1):
	l4.append("<b>"+str(j)+"<br>"+str(l3[i])+"</b>")


fig = px.line(df, x="Line", y="RPM")
fig.update_layout(
    xaxis = dict(
        tickvals = l2,
        ticktext = l4
    )
)
fig.update_yaxes(
        title_text = "RPM",
        title_font = {"size": 20},
        title_standoff = 25)

fig.update_xaxes(
        title_text = "Position",
        title_font = {"size": 20},
        title_standoff = 25)

fig.update_traces(line=dict(color="orange", width=4))

fig.show()


python3 reve.py $1/$2 >$1/$2\_header.txt
RNAfold --noPS -j $1/$2.fasta|paste - - - |awk '{print $1"\t"$2"\t"$3}' >$1/$2\_rnafold
cat $1/$2\_rnafold |tr '(.)' 'MON' >$1/$2\_feature
python3 program.py $1/$2\_feature >$1/$2.log
paste $1/$2_feature.txt $1/$2\_feature |sed 's+\[++'|sed 's+]++' |awk '{if($2>=0.5) {print $3"\tpre-miRNA"} else {print $3"\tNon-pre-miRNA"}}' >$1/sequence_feature.tsv
paste $1/$2_feature.txt $1/$2\_feature |sed 's+\[++' |sed 's+]++' |awk '{print $3","$2","$4","$5}' | tr "MON" "(.)"|sed 's+_+,+1g' >$1/seq.txt
cat $1/$2\_header.txt| while read i ;do grep -Pi "^>$i," seq.txt |grep -i "rev"|awk -F',' '{print $2","$3}'|sed 's+-rev++' >$i-rev.csv ;grep -Pi "^>$i," seq.txt|grep -iv "rev"|awk -F',' '{print $2","$3}' >$i.csv ;done
python3 p2.py $1/$2 $1
cat $1/plot/seq*bed|bedtools sort -i - |bedtools merge -i - -s -c 6 -o distinct -d 16|awk '{if(($3-$2) >16) print $1"\t"$2"\t"$2+280"\tabcd\t255\t"$4}' >$2/$2.bed
python3 p3.py $1/$2 $1
